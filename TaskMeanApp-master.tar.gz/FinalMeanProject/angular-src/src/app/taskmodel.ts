export class Task{
    taskId: Number
    taskName:String
    taskClientName : String
    taskHandler : String
    taskDesc : String

    }
    