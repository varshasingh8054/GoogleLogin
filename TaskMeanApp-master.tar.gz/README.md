# MeanProj

Run following steps in cmd

In MeanProj-master\MeanProj-master -->  $ npm install

In MeanProj-master\MeanProj-master --> $ npm start

In Another cmd Run

In  MeanProj-master\MeanProj-master\angular-src --> $npm install

In  MeanProj-master\MeanProj-master\angular-src--> $ npm install -g @angular/cli

In  MeanProj-master\MeanProj-master\angular-src--> $ npm start

run http://localhost:4200/



