module.exports={
    database: 'mongodb://localhost:27017/meanProject',
  
    secret : 'secret your'
}
